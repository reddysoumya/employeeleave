package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.bean.Leave;
import com.cg.dao.ILeaveDAO;
import com.cg.exception.EmployeeException;


@Service
@Transactional
public class LeaveServiceImpl implements ILeaveService{
	@Autowired
	 ILeaveDAO ldao;
	
	@Override
	public  List<Leave> getEmpLeavesById(int empid) throws EmployeeException {
		return ldao.getEmpLeavesById(empid);
	}

	@Override
	public Employee getEmployeeById(int empid) throws EmployeeException {
		// TODO Auto-generated method stub
		return ldao.getEmployeeById(empid);
	}

}
