package com.cg.dao;

import java.util.List;

import com.cg.bean.Employee;
import com.cg.bean.Leave;
import com.cg.exception.EmployeeException;
public interface ILeaveDAO {

	public List<Leave> getEmpLeavesById(int empid) throws EmployeeException;

	public Employee getEmployeeById(int empid) throws EmployeeException;

}
