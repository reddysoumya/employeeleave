package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.Employee;
import com.cg.bean.Leave;
import com.cg.exception.EmployeeException;
@Repository
public class LeaveDAOImpl implements ILeaveDAO{

	@PersistenceContext
	private EntityManager entitymanager;
	
	@Override
	public List<Leave> getEmpLeavesById(int empid) throws EmployeeException{
		TypedQuery<Leave> query = entitymanager.createQuery("SELECT d FROM Leave d where empid=?", Leave.class);
		query.setParameter(1, empid);
		return query.getResultList();
	}

	@Override
	public Employee getEmployeeById(int empid) throws EmployeeException{	
		return entitymanager.find(Employee.class,empid);
	}

}
